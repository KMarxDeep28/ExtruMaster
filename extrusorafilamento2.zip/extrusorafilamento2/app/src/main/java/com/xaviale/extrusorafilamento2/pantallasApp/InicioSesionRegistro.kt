package com.xaviale.extrusorafilamento2.pantallasApp

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.xaviale.extrusorafilamento2.R
import com.xaviale.extrusorafilamento2.datos.Botones
import com.xaviale.extrusorafilamento2.datos.Campo
import com.xaviale.extrusorafilamento2.datos.Pantallas
import com.xaviale.extrusorafilamento2.datos.VariablesAlmacenadasUsuario
import com.xaviale.extrusorafilamento2.ui.ControlUsuarioModeloVista


@Composable
fun InicioSesionRegistro(
    navControl: NavController, modeloVista: ControlUsuarioModeloVista = viewModel()
) {
    val context = LocalContext.current
    var expandido by remember { mutableStateOf(true) }

    var correo by remember { mutableStateOf("") }
    var contrasenia by remember { mutableStateOf("") }
    var nombreUsuario by remember { mutableStateOf("") }

    val esCorreoValido = modeloVista.validarEmail(correo)
    val esContraseniaValida = modeloVista.validarContrasenia(contrasenia)
    val esNombreUsuarioValido = modeloVista.validarNombreUsuario(nombreUsuario)

    val botonHabilitado = if (expandido) {
        esCorreoValido && esContraseniaValida
    } else {
        esCorreoValido && esContraseniaValida && esNombreUsuarioValido
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .animateContentSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (!expandido) {
            Campo(
                imeaction = ImeAction.Next,
                icono = Icons.Default.Person,
                texto = stringResource(id = R.string.pedirNombreUsuario),
                datos = nombreUsuario,
                datosInsercion = { nombreUsuario = it },
                error = !esNombreUsuarioValido,
                keyboardType = KeyboardType.Text
            )
        }

        Campo(
            imeaction = ImeAction.Next,
            icono = Icons.Default.Email,
            texto = stringResource(id = R.string.pedirCorreo),
            datos = correo,
            datosInsercion = { correo = it },
            error = !esCorreoValido,
            keyboardType = KeyboardType.Email
        )
        Campo(
            icono = Icons.Default.Lock,
            imeaction = ImeAction.Done,
            texto = stringResource(id = R.string.pedirContrasenia),
            datos = contrasenia,
            datosInsercion = { contrasenia = it },
            error = !esContraseniaValida,
            keyboardType = KeyboardType.Password,
            visualTransformation = PasswordVisualTransformation()
        )

        if (expandido) {
            Botones(
                clic = {
                    modeloVista.inicioSesion(correo, contrasenia, context) {
                        modeloVista.almacenarRamDatos()
                        modeloVista.obtenerAlertasUsuario()
                        navControl.navigate(Pantallas.Inicio.pantalla)
                    }
                }, texto = stringResource(id = R.string.inicioSesion), activo = botonHabilitado
            )
        } else {
            Botones(
                clic = {
                    modeloVista.registrarUsuario(nombreUsuario, correo, contrasenia, context) {
                        expandido = !expandido
                        //navControl.navigate(Pantallas.Inicio.pantalla)
                    }
                    VariablesAlmacenadasUsuario.usuarioNombre = nombreUsuario
                    modeloVista.almacenarRamDatos()
                }, texto = stringResource(id = R.string.registrarse), activo = botonHabilitado
            )
        }
        Botones(
            clic = { expandido = !expandido },
            texto = if (expandido) stringResource(id = R.string.registrar) else stringResource(
                id = R.string.volver
            ),
        )
    }
}

@Preview(showBackground = true)
@Composable
private fun GreetingPreview() {
    val navControl = rememberNavController()
    InicioSesionRegistro(navControl)
}