package com.xaviale.extrusorafilamento2.pantallasApp

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.xaviale.extrusorafilamento2.R
import com.xaviale.extrusorafilamento2.datos.ALERTA
import com.xaviale.extrusorafilamento2.datos.Botones
import com.xaviale.extrusorafilamento2.datos.CONECTADO
import com.xaviale.extrusorafilamento2.datos.DESCONECTADO
import com.xaviale.extrusorafilamento2.datos.TEMPERATURA_DESEADA
import com.xaviale.extrusorafilamento2.datos.TEMPERATURA_DESEADABT
import com.xaviale.extrusorafilamento2.datos.TRANSFERENCIA
import com.xaviale.extrusorafilamento2.datos.VELOCIDAD_MOTOR
import com.xaviale.extrusorafilamento2.datos.VELOCIDAD_MOTORBT
import com.xaviale.extrusorafilamento2.datos.VariablesAlmacenadasExtrusora
import com.xaviale.extrusorafilamento2.ui.ControlPrincipalModeloVista
import com.xaviale.extrusorafilamento2.ui.ControlUsuarioModeloVista
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun Inicio(controlPrincipalModeloVista: ControlPrincipalModeloVista = viewModel()) {
    // Reproductor de sonido de alerta
    val currentContext = LocalContext.current
    val mediaPlayer = remember {
        MediaPlayer.create(currentContext, R.raw.beep)
    }
    // Referencia a la base de datos Firebase
    var wifiState by remember { mutableStateOf(VariablesAlmacenadasExtrusora.wifiEstado == 1) }
    var bluetoothState by remember { mutableStateOf(VariablesAlmacenadasExtrusora.bluetoothEstado == 1) }

    var disableButtons by remember { mutableStateOf(false) }

    var velocidadMotorTemp by remember { mutableIntStateOf(0) }
    var temperaturaDeseadaTemp by remember { mutableIntStateOf(0) }

    val conexion =
        if (VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado == DESCONECTADO) stringResource(
            id = R.string.conectar
        ) else stringResource(
            id = R.string.desconectar
        )
    val conexionwifi =
        if (VariablesAlmacenadasExtrusora.estadoConexionWifiEstado == DESCONECTADO) stringResource(
            id = R.string.conectar
        ) else stringResource(
            id = R.string.desconectar
        )
    val listo =
        if (VariablesAlmacenadasExtrusora.alertaEstado == 0) stringResource(id = R.string.listo) else stringResource(
            id = R.string.alerta
        )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            if (VariablesAlmacenadasExtrusora.modoConexionEstado) stringResource(
                id = R.string.bluetooth
            ) else stringResource(
                id = R.string.wifi
            )
        )

        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            //Bluetooth
            if (VariablesAlmacenadasExtrusora.modoConexionEstado) {
                Botones(
                    clic = {
                        if (VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado == DESCONECTADO) {


                            if (ActivityCompat.checkSelfPermission(
                                    currentContext,
                                    Manifest.permission.BLUETOOTH
                                ) == PackageManager.PERMISSION_GRANTED &&
                                ActivityCompat.checkSelfPermission(
                                    currentContext,
                                    Manifest.permission.BLUETOOTH_ADMIN
                                ) == PackageManager.PERMISSION_GRANTED &&
                                ActivityCompat.checkSelfPermission(
                                    currentContext,
                                    Manifest.permission.ACCESS_FINE_LOCATION
                                ) == PackageManager.PERMISSION_GRANTED
                            ) {
                                controlPrincipalModeloVista.conectarBluetooth(currentContext) { state ->
                                    controlPrincipalModeloVista.estadoConexionBluetooth = state

                                }

                            } else {
                                ActivityCompat.requestPermissions(
                                    currentContext as ComponentActivity,
                                    arrayOf(
                                        Manifest.permission.BLUETOOTH,
                                        Manifest.permission.BLUETOOTH_ADMIN,
                                        Manifest.permission.ACCESS_FINE_LOCATION
                                    ),
                                    1
                                )
                            }
                        } else {
                            controlPrincipalModeloVista.desconectarBluetooth()
                            VariablesAlmacenadasExtrusora.bluetoothEstado = 0
                            bluetoothState = false
                        }
                    },
                    texto = conexion,
                    activo = true
                )

                if (VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado == CONECTADO) {

                    Text(
                        text = listo,
                        color = if (VariablesAlmacenadasExtrusora.alertaEstado == 0) Color.Green else Color.Red,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                } else {
                    Text(
                        text = stringResource(id = R.string.desconectado),
                        color = Color.Gray,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            } else {
// Botón de Wi-Fi
                Botones(
                    clic = {


                        VariablesAlmacenadasExtrusora.estadoConexionWifiEstado =
                            if (VariablesAlmacenadasExtrusora.estadoConexionWifiEstado == DESCONECTADO) CONECTADO else DESCONECTADO


                        if (VariablesAlmacenadasExtrusora.estadoConexionWifiEstado == DESCONECTADO) {
                            VariablesAlmacenadasExtrusora.wifiEstado = 0
                            wifiState = false
                        }
                    },

                    texto = conexionwifi,
                    modifier = Modifier.padding(horizontal = 8.dp),
                    activo = true
                )
                if (VariablesAlmacenadasExtrusora.estadoConexionWifiEstado == CONECTADO) {
                    Text(
                        text = listo,
                        color = if (VariablesAlmacenadasExtrusora.alertaEstado == 0) Color.Green else Color.Red,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                } else {
                    Text(
                        text = stringResource(id = R.string.desconectado),
                        color = Color.Gray,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }

        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(
                    id = R.string.temperaturaActualDeseada,
                    VariablesAlmacenadasExtrusora.temperaturaActualEstado,
                    VariablesAlmacenadasExtrusora.temperaturaDeseadaEstado

                )
            )
            if (VariablesAlmacenadasExtrusora.modoConexionEstado) {


                Switch(
                    checked = bluetoothState,
                    onCheckedChange = { checked ->
                        bluetoothState = checked
                        VariablesAlmacenadasExtrusora.bluetoothEstado = if (checked) 1 else 0
                    },
                    enabled = VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado == CONECTADO
                )
                //Text(text = if (VariablesAlmacenadasExtrusora.bluetoothEstado == 1) "ON" else "OFF")
            } else {

                Switch(
                    checked = wifiState,
                    onCheckedChange = { checked ->
                        wifiState = checked
                        VariablesAlmacenadasExtrusora.wifiEstado = if (checked) 1 else 0
                    },
                    enabled = VariablesAlmacenadasExtrusora.estadoConexionWifiEstado == CONECTADO
                )
                //Text(text = if (VariablesAlmacenadasExtrusora.wifiEstado == 1) "ON" else "OFF")
            }
        }

        Row {
            Text(
                stringResource(
                    id = R.string.temperaturaDeseada,
                    temperaturaDeseadaTemp
                )
            )
            Slider(
                value = temperaturaDeseadaTemp.toFloat(),
                onValueChange = { newValue ->
                    temperaturaDeseadaTemp = newValue.toInt()
                },
                valueRange = 0f..260f,
                steps = 260,
                enabled = ((VariablesAlmacenadasExtrusora.wifiEstado == 0 && VariablesAlmacenadasExtrusora.transferenciaEstado == 0 && VariablesAlmacenadasExtrusora.estadoConexionWifiEstado == CONECTADO) || (VariablesAlmacenadasExtrusora.bluetoothEstado == 0 && VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado == CONECTADO)) && VariablesAlmacenadasExtrusora.alertaEstado == 0
            )
        }
        Botones(
            clic = {
                if (VariablesAlmacenadasExtrusora.modoConexionEstado) {
                    if (VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado == CONECTADO && VariablesAlmacenadasExtrusora.bluetoothEstado == 0) {
                        controlPrincipalModeloVista.enviarMensajeBluetooth(
                            TEMPERATURA_DESEADABT + temperaturaDeseadaTemp
                        )
                    }


                } else {

                    if (VariablesAlmacenadasExtrusora.estadoConexionWifiEstado == CONECTADO && VariablesAlmacenadasExtrusora.wifiEstado == 0) {
                        controlPrincipalModeloVista.referenciaBaseDatos.child(
                            TEMPERATURA_DESEADA
                        )
                            .setValue(temperaturaDeseadaTemp)

                        VariablesAlmacenadasExtrusora.transferenciaEstado = 3
                        controlPrincipalModeloVista.referenciaBaseDatos.child(
                            TRANSFERENCIA
                        )
                            .setValue(VariablesAlmacenadasExtrusora.transferenciaEstado)
                    }


                }
                //disableButtons = true
                CoroutineScope(Dispatchers.Main).launch {
                    delay(1000)
                    //disableButtons = false
                }
            },
            texto = stringResource(id = R.string.guardarTemperatura),
            activo = ((VariablesAlmacenadasExtrusora.wifiEstado == 0 && VariablesAlmacenadasExtrusora.transferenciaEstado == 0 && VariablesAlmacenadasExtrusora.estadoConexionWifiEstado == CONECTADO) || (VariablesAlmacenadasExtrusora.bluetoothEstado == 0 && VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado == CONECTADO)) && VariablesAlmacenadasExtrusora.alertaEstado == 0

            //activo = (VariablesAlmacenadas.estadoConexionBluetoothEstado == CONECTADO || VariablesAlmacenadas.wifiEstado == 1) && !disableButtons && VariablesAlmacenadas.alertaEstado == 0
        )
        Text(
            text = stringResource(
                id = R.string.velocidadMotor,
                VariablesAlmacenadasExtrusora.velocidadMotorEstado
            )
        )

        Row {
            Text(stringResource(id = R.string.velocidadMotor, velocidadMotorTemp))
            Slider(
                value = velocidadMotorTemp.toFloat(),
                onValueChange = { newValue ->
                    velocidadMotorTemp = newValue.toInt()
                },
                valueRange = 0f..255f,
                steps = 255,
                enabled = ((VariablesAlmacenadasExtrusora.wifiEstado == 0 && VariablesAlmacenadasExtrusora.transferenciaEstado == 0 && VariablesAlmacenadasExtrusora.estadoConexionWifiEstado == CONECTADO) || (VariablesAlmacenadasExtrusora.bluetoothEstado == 0 && VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado == CONECTADO)) && VariablesAlmacenadasExtrusora.alertaEstado == 0
            )
        }
        Botones(
            clic = {
                if (VariablesAlmacenadasExtrusora.modoConexionEstado) {
                    if (VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado == CONECTADO && VariablesAlmacenadasExtrusora.bluetoothEstado == 0) {
                        controlPrincipalModeloVista.enviarMensajeBluetooth(
                            VELOCIDAD_MOTORBT + velocidadMotorTemp
                        )
                    }


                } else {
                    if (VariablesAlmacenadasExtrusora.estadoConexionWifiEstado == CONECTADO && VariablesAlmacenadasExtrusora.wifiEstado == 0) {
                        controlPrincipalModeloVista.referenciaBaseDatos.child(
                            VELOCIDAD_MOTOR
                        )
                            .setValue(velocidadMotorTemp)



                        VariablesAlmacenadasExtrusora.transferenciaEstado = 4
                        controlPrincipalModeloVista.referenciaBaseDatos.child(
                            TRANSFERENCIA
                        )
                            .setValue(VariablesAlmacenadasExtrusora.transferenciaEstado)
                    }


                }
                disableButtons = true
                CoroutineScope(Dispatchers.Main).launch {
                    delay(1000)
                    disableButtons = false
                }
            },
            texto = stringResource(id = R.string.guardarVelocidad),
            activo = ((VariablesAlmacenadasExtrusora.wifiEstado == 0 && VariablesAlmacenadasExtrusora.transferenciaEstado == 0 && VariablesAlmacenadasExtrusora.estadoConexionWifiEstado == CONECTADO) || (VariablesAlmacenadasExtrusora.bluetoothEstado == 0 && VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado == CONECTADO)) && VariablesAlmacenadasExtrusora.alertaEstado == 0
            //activo = (VariablesAlmacenadas.estadoConexionBluetoothEstado == CONECTADO || VariablesAlmacenadas.wifiEstado == 1) && !disableButtons && VariablesAlmacenadas.alertaEstado == 0
        )
        Row {

            Botones(
                clic = {
                    VariablesAlmacenadasExtrusora.alertaEstado = 0
                    if (VariablesAlmacenadasExtrusora.modoConexionEstado) {
                        if (VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado == CONECTADO && VariablesAlmacenadasExtrusora.bluetoothEstado == 0) {
                            controlPrincipalModeloVista.enviarMensajeBluetooth("$ALERTA:0")
                        }

                    } else {
                        if (VariablesAlmacenadasExtrusora.estadoConexionWifiEstado == CONECTADO && VariablesAlmacenadasExtrusora.wifiEstado == 0) {
                            controlPrincipalModeloVista.referenciaBaseDatos.child(ALERTA)
                                .setValue(VariablesAlmacenadasExtrusora.alertaEstado)
                            VariablesAlmacenadasExtrusora.transferenciaEstado = 2
                            controlPrincipalModeloVista.referenciaBaseDatos.child(
                                TRANSFERENCIA
                            )
                                .setValue(VariablesAlmacenadasExtrusora.transferenciaEstado)
                        }


                    }

                    //disableButtons = true
                    CoroutineScope(Dispatchers.Main).launch {
                        delay(1000)
                        //disableButtons = false
                    }
                },
                texto = stringResource(id = R.string.reiniciar),
                //activo = (VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado == CONECTADO || VariablesAlmacenadasExtrusora.wifiEstado == 1) && VariablesAlmacenadasExtrusora.alertaEstado == 1 && !disableButtons,
                activo = VariablesAlmacenadasExtrusora.alertaEstado == 1

            )
        }

        LaunchedEffect(Unit) {
            controlPrincipalModeloVista.alertasSonido(mediaPlayer, controlPrincipalModeloVista)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            mediaPlayer.release()
        }
    }

    if (VariablesAlmacenadasExtrusora.alertaEstado == 1){
        val usuarioModeloVista: ControlUsuarioModeloVista = viewModel()
        usuarioModeloVista.guardarAlertaEnBaseDeDatos()
    }
}

@Preview
@Composable
private fun InicioPreview() {
    Inicio()
}