package com.xaviale.extrusorafilamento2.ui

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.ActivityCompat
import androidx.lifecycle.ViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.xaviale.extrusorafilamento2.datos.ALERTA
import com.xaviale.extrusorafilamento2.datos.CONECTADO
import com.xaviale.extrusorafilamento2.datos.DESCONECTADO
import com.xaviale.extrusorafilamento2.datos.MI_UUID
import com.xaviale.extrusorafilamento2.datos.TEMPERATURA_ACTUAL
import com.xaviale.extrusorafilamento2.datos.TEMPERATURA_DESEADA
import com.xaviale.extrusorafilamento2.datos.TRANSFERENCIA
import com.xaviale.extrusorafilamento2.datos.VELOCIDAD_MOTOR
import com.xaviale.extrusorafilamento2.datos.VariablesAlmacenadasExtrusora
import kotlinx.coroutines.delay
import java.io.IOException
import java.util.UUID

class ControlPrincipalModeloVista : ViewModel() {
    var velocidadMotor by mutableIntStateOf(VariablesAlmacenadasExtrusora.velocidadMotorEstado)
    var temperaturaDeseada by mutableIntStateOf(VariablesAlmacenadasExtrusora.temperaturaDeseadaEstado)
    var transferencia by mutableIntStateOf(VariablesAlmacenadasExtrusora.transferenciaEstado)
    var alerta by mutableIntStateOf(VariablesAlmacenadasExtrusora.alertaEstado)
    private var isUpdating = VariablesAlmacenadasExtrusora.isUpdatingEstado
    private var wifi by mutableIntStateOf(VariablesAlmacenadasExtrusora.wifiEstado)
    var temperaturaActual by mutableIntStateOf(VariablesAlmacenadasExtrusora.temperaturaActualEstado)
    var estadoConexionBluetooth by mutableStateOf(VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado)

    private val MY_UUID: UUID = UUID.fromString(MI_UUID)
    var referenciaBaseDatos = Firebase.database.reference

    private var bluetoothSocket: BluetoothSocket? = null

    private var intentosFallidoActualizacion by mutableIntStateOf(0)

    fun conectarBluetooth(context: Context, onStateChanged: (String) -> Unit) {
        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter() ?: return

        if (!bluetoothAdapter.isEnabled) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            if (ActivityCompat.checkSelfPermission(
                    context, Manifest.permission.BLUETOOTH_CONNECT
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }
            context.startActivity(enableBtIntent)
            return
        }

        val esp32Address = "CC:50:E3:9C:2E:1A" // Cambiar por la dirección MAC de tu ESP32-CAM
        val esp32Device: BluetoothDevice? = bluetoothAdapter.getRemoteDevice(esp32Address)

        try {
            bluetoothSocket = esp32Device?.createRfcommSocketToServiceRecord(MY_UUID)
            bluetoothSocket?.connect()
            onStateChanged(CONECTADO)
            VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado = CONECTADO
            //VariablesAlmacenadasExtrusora.bluetoothEstado = 1
        } catch (e: IOException) {
            e.printStackTrace()
            onStateChanged(DESCONECTADO)
            VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado = DESCONECTADO

        }
    }

    fun enviarMensajeBluetooth(mensaje: String) {
        try {
            bluetoothSocket?.let { socket ->
                val outputStream = socket.outputStream
                outputStream.write(mensaje.toByteArray())
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    suspend fun actualizarTodasLasVariables(onUpdate: suspend () -> Unit) {
        try {
            isUpdating = true
            VariablesAlmacenadasExtrusora.isUpdatingEstado = isUpdating
            bluetoothSocket?.let { socket ->
                val outputStream = socket.outputStream
                val inputStream = socket.inputStream

                // Enviar el comando "actualizar"
                outputStream.write("actualizar\n".toByteArray())
                outputStream.flush()

                delay(500) // Esperar a que llegue la respuesta

                val responseBuffer = ByteArray(1024)
                val bytesRead = inputStream.read(responseBuffer)
                val response = String(responseBuffer, 0, bytesRead).trim()

                // Parsear la respuesta
                val parts = response.split(',')
                if (parts.size == 4) {
                    temperaturaActual = parts[0].toIntOrNull() ?: 0
                    VariablesAlmacenadasExtrusora.temperaturaActualEstado = temperaturaActual
                    temperaturaDeseada = parts[1].toIntOrNull() ?: 0
                    VariablesAlmacenadasExtrusora.temperaturaDeseadaEstado = temperaturaDeseada
                    velocidadMotor = parts[2].toIntOrNull() ?: 0
                    VariablesAlmacenadasExtrusora.velocidadMotorEstado = velocidadMotor
                    alerta = parts[3].toIntOrNull() ?: 0
                    VariablesAlmacenadasExtrusora.alertaEstado = alerta
                    onUpdate()
                    estadoConexionBluetooth = CONECTADO
                    VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado =
                        estadoConexionBluetooth
                } else {
                    // Handle incorrect response
                }

                // Reiniciar el contador de intentos fallidos
                intentosFallidoActualizacion = 0
            }
        } catch (e: Exception) {
            e.printStackTrace()
            intentosFallidoActualizacion++
            if (intentosFallidoActualizacion >= 3) {
                desconectarBluetooth()
            }
        } finally {
            isUpdating = false
            VariablesAlmacenadasExtrusora.isUpdatingEstado = isUpdating
        }
    }


    suspend fun actualizarTodasLasVariablesFirebase(
        onUpdate: suspend () -> Unit
    ) {
        referenciaBaseDatos = Firebase.database.reference
        isUpdating = true
        VariablesAlmacenadasExtrusora.isUpdatingEstado = isUpdating
        try {

            referenciaBaseDatos.child(VELOCIDAD_MOTOR)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        velocidadMotor = snapshot.getValue(Int::class.java) ?: 0
                        // isUpdating = false
                        VariablesAlmacenadasExtrusora.velocidadMotorEstado = velocidadMotor

                    }

                    override fun onCancelled(error: DatabaseError) {}
                })

            referenciaBaseDatos.child(TEMPERATURA_DESEADA)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        temperaturaDeseada = snapshot.getValue(Int::class.java) ?: 0
                        //  isUpdating = false
                        VariablesAlmacenadasExtrusora.temperaturaDeseadaEstado = temperaturaDeseada

                    }

                    override fun onCancelled(error: DatabaseError) {}
                })

            referenciaBaseDatos.child(TEMPERATURA_ACTUAL)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        temperaturaActual = snapshot.getValue(Int::class.java) ?: 0
                        VariablesAlmacenadasExtrusora.temperaturaActualEstado = temperaturaActual
                        // isUpdating = false
                    }

                    override fun onCancelled(error: DatabaseError) {}
                })

            referenciaBaseDatos.child(ALERTA)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        alerta = snapshot.getValue(Int::class.java) ?: 0
                        //isUpdating = false
                        VariablesAlmacenadasExtrusora.alertaEstado = alerta
                    }

                    override fun onCancelled(error: DatabaseError) {}
                })
            onUpdate()
        } catch (e: Exception) {
            e.printStackTrace()
            intentosFallidoActualizacion++
            if (intentosFallidoActualizacion >= 3) {
                wifi = 0
                VariablesAlmacenadasExtrusora.wifiEstado = wifi
            }
        } finally {
            isUpdating = false
            VariablesAlmacenadasExtrusora.isUpdatingEstado = isUpdating
        }
    }


    suspend fun actualizarDesdeFirebase(
        onUpdate: suspend () -> Unit
    ) {
        referenciaBaseDatos = Firebase.database.reference
        isUpdating = true
        VariablesAlmacenadasExtrusora.isUpdatingEstado = isUpdating
        try {

            referenciaBaseDatos.child(TRANSFERENCIA)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        transferencia = snapshot.getValue(Int::class.java) ?: 0
                        // isUpdating = false
                        VariablesAlmacenadasExtrusora.transferenciaEstado = transferencia
                    }

                    override fun onCancelled(error: DatabaseError) {}
                })
            onUpdate()
        } catch (e: Exception) {
            e.printStackTrace()
            intentosFallidoActualizacion++
            if (intentosFallidoActualizacion >= 3) {
                wifi = 0
                VariablesAlmacenadasExtrusora.wifiEstado = wifi
            }
        } finally {
            isUpdating = false
            VariablesAlmacenadasExtrusora.isUpdatingEstado = isUpdating
        }
    }

    suspend fun alertasSonido(
        mediaPlayer: MediaPlayer, controlPrincipalModeloVista: ControlPrincipalModeloVista
    ) {
        var isAlertPlaying = false
        while (true) {
            if (!VariablesAlmacenadasExtrusora.isUpdatingEstado) {
                if (VariablesAlmacenadasExtrusora.modoConexionEstado) {
                    if (VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado == CONECTADO
                        && VariablesAlmacenadasExtrusora.bluetoothEstado == 1) {
                        controlPrincipalModeloVista.actualizarTodasLasVariables {
                            if (VariablesAlmacenadasExtrusora.alertaEstado == 1) {
                                if (!isAlertPlaying) {
                                    mediaPlayer.start()
                                    isAlertPlaying = true
                                } else {
                                    mediaPlayer.seekTo(0)
                                    mediaPlayer.start()
                                }
                            } else if (isAlertPlaying) {
                                mediaPlayer.pause()
                                mediaPlayer.seekTo(0)
                                isAlertPlaying = false
                            }
                            delay(500)
                        }
                    }
                } else {
                    if (VariablesAlmacenadasExtrusora.wifiEstado == 1
                        && VariablesAlmacenadasExtrusora.estadoConexionWifiEstado == CONECTADO) {
                        controlPrincipalModeloVista.transferencia = 1
                        controlPrincipalModeloVista.referenciaBaseDatos.child(TRANSFERENCIA)
                            .setValue(controlPrincipalModeloVista.transferencia)
                        delay(1000)
                        while (controlPrincipalModeloVista.transferencia == 1) {
                            controlPrincipalModeloVista.actualizarDesdeFirebase {
                                delay(1000)
                            }
                        }
                        if (controlPrincipalModeloVista.transferencia == 0) {
                            controlPrincipalModeloVista.actualizarTodasLasVariablesFirebase {
                                if (controlPrincipalModeloVista.alerta == 1) {
                                    if (!isAlertPlaying) {
                                        mediaPlayer.start()
                                        isAlertPlaying = true
                                    } else {
                                        mediaPlayer.seekTo(0)
                                        mediaPlayer.start()
                                    }
                                } else if (isAlertPlaying) {
                                    mediaPlayer.pause()
                                    mediaPlayer.seekTo(0)
                                    isAlertPlaying = false
                                }
                                delay(500)
                            }
                        }
                    }
                }
            }
            delay(500)
        }
    }

    fun desconectarBluetooth() {
        bluetoothSocket?.close()
        estadoConexionBluetooth = DESCONECTADO
        VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado = estadoConexionBluetooth
        // temperaturaActual = 0
    }

}