package com.xaviale.extrusorafilamento2.datos

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun Campo(
    imeaction: ImeAction,
    icono: ImageVector,
    texto: String,
    datos: String,
    datosInsercion: (String) -> Unit,
    error: Boolean = false,
    keyboardType: KeyboardType,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    modifier: Modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 15.dp)
) {
    OutlinedTextField(
        value = datos,
        onValueChange = datosInsercion,
        modifier = modifier,
        label = {
            Text(
                text = texto,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
        },
        leadingIcon = {
            Icon(
                imageVector = icono,
                contentDescription = texto
            )
        },
        isError = error,
        keyboardOptions = KeyboardOptions.Default.copy(
            keyboardType = keyboardType,
            imeAction = imeaction
        ),
        singleLine = true,
        visualTransformation = visualTransformation
    )
}

@Composable
fun Botones(
    clic: () -> Unit,
    texto: String,
    modifier: Modifier = Modifier,
    activo: Boolean = true
) {
    Button(
        onClick = clic,
        modifier = modifier,
        enabled = activo
    ) {
        Text(text = texto)
    }
}