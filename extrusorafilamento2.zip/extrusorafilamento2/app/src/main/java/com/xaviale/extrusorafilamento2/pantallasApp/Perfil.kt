package com.xaviale.extrusorafilamento2.pantallasApp

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.google.firebase.auth.FirebaseAuth
import com.xaviale.extrusorafilamento2.R
import com.xaviale.extrusorafilamento2.datos.Alerta
import com.xaviale.extrusorafilamento2.datos.Botones
import com.xaviale.extrusorafilamento2.datos.Campo
import com.xaviale.extrusorafilamento2.datos.Pantallas
import com.xaviale.extrusorafilamento2.datos.VariablesAlmacenadasUsuario
import com.xaviale.extrusorafilamento2.ui.ControlUsuarioModeloVista
import java.util.Date

@Composable
fun Perfil(
    navControl: NavController, modeloVista: ControlUsuarioModeloVista = viewModel()
) {
    val contexto = LocalContext.current
    var nombreUsuario by remember { mutableStateOf(VariablesAlmacenadasUsuario.usuarioNombre) }
    val correo by remember { mutableStateOf(FirebaseAuth.getInstance().currentUser?.email.toString()) }

    val esNombreUsuarioValido = modeloVista.validarNombreUsuario(nombreUsuario)
    val alertas by remember { mutableStateOf(VariablesAlmacenadasUsuario.alertas) }

    Column(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = stringResource(id = R.string.correoRec, correo)
        )

        Campo(
            imeaction = ImeAction.Done,
            icono = Icons.Default.Person,
            texto = stringResource(id = R.string.pedirNombreUsuario),
            datos = nombreUsuario,
            datosInsercion = { nombreUsuario = it },
            error = !esNombreUsuarioValido,
            keyboardType = KeyboardType.Text
        )

        Text(
            text = stringResource(id = R.string.historial)
        )

        Botones(
            clic = {
                modeloVista.actualizarNombreUsuario(nombreUsuario, contexto) {
                    navControl.navigate(Pantallas.InicioSesionRegistro.pantalla)
                }
            },
            texto = stringResource(id = R.string.actualizarPerfil),
            activo = esNombreUsuarioValido
        )

        Botones(
            clic = {
                modeloVista.cerrarSesion{
                    navControl.navigate(Pantallas.InicioSesionRegistro.pantalla)
                }

            }, texto = stringResource(id = R.string.cerrarSesion)
        )

        LazyColumn {
            items(alertas) { alerta ->
                Text(text = "Alerta: ${alerta.alerta.toString()}, Timestamp: ${Date(alerta.timestamp).toString()}")
            }
        }
    }
}

@Preview
@Composable
private fun PerfilPreview() {
    val navegacionControl = rememberNavController()
    Perfil(navegacionControl)
}