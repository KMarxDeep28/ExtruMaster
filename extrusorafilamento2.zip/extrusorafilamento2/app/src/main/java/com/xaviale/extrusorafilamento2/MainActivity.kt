package com.xaviale.extrusorafilamento2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.firebase.auth.FirebaseAuth
import com.xaviale.extrusorafilamento2.datos.Pantallas
import com.xaviale.extrusorafilamento2.datos.VariablesAlmacenadasUsuario
import com.xaviale.extrusorafilamento2.datos.pantallaDato
import com.xaviale.extrusorafilamento2.pantallasApp.Bienvenida
import com.xaviale.extrusorafilamento2.pantallasApp.Configuracion
import com.xaviale.extrusorafilamento2.pantallasApp.Inicio
import com.xaviale.extrusorafilamento2.pantallasApp.InicioSesionRegistro
import com.xaviale.extrusorafilamento2.pantallasApp.Perfil
import com.xaviale.extrusorafilamento2.ui.theme.Extrusorafilamento2Theme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        installSplashScreen()

        setContent {
            Extrusorafilamento2Theme {
                // A surface container using the 'background' color from the theme
                Surface(color = MaterialTheme.colorScheme.background) {
                    val navegacionControl = rememberNavController()
                    var splashShown by remember { mutableStateOf(true) }

                    LaunchedEffect(Unit) {
                        // Mostrar el splash screen por 2 segundos
                        delay(100)
                        splashShown = false
                    }

                    if (splashShown) {
                        Bienvenida()
                    } else {

                        LaunchedEffect(Unit) {
                            delay(1)
                            if (FirebaseAuth.getInstance().currentUser?.email.isNullOrEmpty()) {
                                navegacionControl.navigate(Pantallas.Inicio.pantalla) {
                                    popUpTo(0) { inclusive = true }
                                }
                            } else {
                                navegacionControl.navigate(Pantallas.InicioSesionRegistro.pantalla) {
                                    popUpTo(0) { inclusive = true }
                                }
                            }
                        }
                        InterfazPrincipal(navegacionControl)
                    }
                }
            }
        }
    }
}

@Composable
private fun InterfazPrincipal(navegacionControl: NavHostController) {
    val alcanceCortina = rememberCoroutineScope()
    val estadoCajon = rememberDrawerState(initialValue = DrawerValue.Closed)
    ModalNavigationDrawer(
        drawerContent = {
            MenuLateral(
                alcanceCorrutina = alcanceCortina,
                estadoCajon = estadoCajon,
                navegacionControl = navegacionControl
            )
        },
        drawerState = estadoCajon,
        gesturesEnabled = true
    ) {
        Scaffold(
            topBar = {
                BarraSuperior(
                    alcanceCortina = alcanceCortina,
                    estadoCajon = estadoCajon,
                    navegacionControl = navegacionControl
                )
            },
        )
        {
            Box(
                modifier = Modifier.padding(it)
            ) {
                PantallasNavegacion(
                    navegacionHostControl = navegacionControl
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BarraSuperior(
    alcanceCortina: CoroutineScope,
    estadoCajon: DrawerState,
    navegacionControl: NavController
) {
    CenterAlignedTopAppBar(
        title = {
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = {
                    if (navegacionControl.currentDestination?.route != Pantallas.InicioSesionRegistro.pantalla) {
                        alcanceCortina.launch {
                            estadoCajon.open()
                        }
                    }
                }) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = stringResource(id = R.string.menu)
                    )
                }
                Text(text = stringResource(id = R.string.app_name))
            }
        }
    )
}

@Composable
private fun MenuLateral(
    alcanceCorrutina: CoroutineScope,
    estadoCajon: DrawerState,
    navegacionControl: NavController
) {
    ModalDrawerSheet(
        modifier = Modifier.fillMaxWidth(0.8f)
    ) {
        BanerMenu()
        HorizontalDivider()
        pantallaDato.forEach {
            NavigationDrawerItem(
                label = { Text(text = stringResource(id = it.etiqueta)) },
                selected = false,
                onClick = {
                    alcanceCorrutina.launch {
                        estadoCajon.close()
                    }
                    navegacionControl.navigate(it.pantallas.pantalla) {
                        popUpTo(0)
                    }
                },
                icon = {
                    Icon(
                        imageVector = it.icono,
                        contentDescription = stringResource(id = it.etiqueta)
                    )
                }
            )
        }
    }
}

@Composable
private fun BanerMenu(
) {
    Box(
        modifier = Modifier
            .background(Color.Gray)
            .fillMaxWidth()
            .height(height = 150.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = stringResource(
                    id = R.string.nombreBarra,
                    VariablesAlmacenadasUsuario.usuarioNombre
                )
            )
            Text(
                text = stringResource(
                    id = R.string.correoBarra,
                    FirebaseAuth.getInstance().currentUser?.email.toString()
                )
            )
        }
    }
}

@Composable
private fun PantallasNavegacion(
    navegacionHostControl: NavHostController
) {
    NavHost(
        navController = navegacionHostControl,
        startDestination = Pantallas.Inicio.pantalla
    ) {
        composable(Pantallas.Inicio.pantalla) { Inicio() }
        composable(Pantallas.Perfil.pantalla) { Perfil(navegacionHostControl) }
        composable(Pantallas.Configuracion.pantalla) { Configuracion() }
        composable(Pantallas.InicioSesionRegistro.pantalla) {
            InicioSesionRegistro(
                navegacionHostControl
            )
        }
    }
}

@Preview
@Composable
private fun InterfazPrincipalPreview() {
    Extrusorafilamento2Theme {
        val navegacionControl = rememberNavController()
        InterfazPrincipal(navegacionControl)
    }
}