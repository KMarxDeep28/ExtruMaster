package com.xaviale.extrusorafilamento2.datos

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class UsuariosDatos(
    var id: String?, val idUsuario: String, var nombreUsuario: String
) {
    fun paraAsignar(): MutableMap<String, Any> {
        return mutableMapOf(
            "usuario_id" to idUsuario, "nombre_usuario" to nombreUsuario
        )
    }
}

object VariablesAlmacenadasUsuario {
    var usuarioNombre: String by mutableStateOf("")
    var alertas by mutableStateOf<List<Alerta>>(emptyList())
}

data class Alerta(
    val usuario_id: String = "",
    val alerta: Int = 0,
    val timestamp: Long = 0
)