package com.xaviale.extrusorafilamento2.datos

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.xaviale.extrusorafilamento2.R

sealed class Pantallas(val pantalla: String) {
    data object Inicio : Pantallas("Inicio")
    data object Perfil : Pantallas("Perfil")
    data object Configuracion : Pantallas("Configuracion")
    data object InicioSesionRegistro : Pantallas("InicioSesionRegistro")
}

data class PantallaItem(
    val pantallas: Pantallas, val icono: ImageVector, @StringRes val etiqueta: Int
)

val pantallaDato = listOf(
    PantallaItem(Pantallas.Inicio, Icons.Default.Home, R.string.inicio),
    PantallaItem(Pantallas.Perfil, Icons.Default.AccountCircle, R.string.perfil),
    PantallaItem(Pantallas.Configuracion, Icons.Default.Settings, R.string.configuracion)
)
