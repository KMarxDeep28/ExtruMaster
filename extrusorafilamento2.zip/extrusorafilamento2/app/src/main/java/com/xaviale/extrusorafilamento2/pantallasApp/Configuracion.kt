package com.xaviale.extrusorafilamento2.pantallasApp

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.xaviale.extrusorafilamento2.R
import com.xaviale.extrusorafilamento2.datos.DESCONECTADO
import com.xaviale.extrusorafilamento2.datos.VariablesAlmacenadasExtrusora
import com.xaviale.extrusorafilamento2.ui.ControlPrincipalModeloVista

@Composable
fun Configuracion(controlPrincipalModeloVista: ControlPrincipalModeloVista = viewModel()) {
    var modoOscuro by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        SwitchItem(
            titulo = stringResource(id = R.string.modoOscuro),
            estadoSwitch = modoOscuro,
            estadoSwitchCambio = { modoOscuro = it }
        )

        Text(stringResource(id = R.string.tipoConexion))
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = VariablesAlmacenadasExtrusora.modoConexionEstado,
                onClick = {
                    if (!VariablesAlmacenadasExtrusora.isUpdatingEstado) {
                        VariablesAlmacenadasExtrusora.modoConexionEstado =
                            !VariablesAlmacenadasExtrusora.modoConexionEstado
                        VariablesAlmacenadasExtrusora.wifiEstado = 0
                        VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado =
                            DESCONECTADO
                    }
                }
            )
            Text(
                text = stringResource(id = R.string.bluetooth),
                modifier = Modifier.padding(start = 8.dp)
            )
        }
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = !VariablesAlmacenadasExtrusora.modoConexionEstado,
                onClick = {
                    if (!VariablesAlmacenadasExtrusora.isUpdatingEstado) {
                        VariablesAlmacenadasExtrusora.modoConexionEstado =
                            !VariablesAlmacenadasExtrusora.modoConexionEstado
                        VariablesAlmacenadasExtrusora.wifiEstado = 0
                        VariablesAlmacenadasExtrusora.estadoConexionBluetoothEstado =
                            DESCONECTADO
                    }
                }
            )
            Text(
                text = stringResource(id = R.string.wifi),
                modifier = Modifier.padding(start = 8.dp)
            )
        }
    }
}

@Composable
fun SwitchItem(
    titulo: String,
    estadoSwitch: Boolean,
    estadoSwitchCambio: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(text = titulo)
        }
        Switch(
            checked = estadoSwitch,
            onCheckedChange = estadoSwitchCambio,
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}


@Preview
@Composable
fun PreviewPantallaConfiguracion() {
    Configuracion()
}