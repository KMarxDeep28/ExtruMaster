package com.xaviale.extrusorafilamento2.datos

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.MutableLiveData

//Direccion MAC
const val  MI_UUID="00001101-0000-1000-8000-00805F9B34FB"
//Estados
const val DESCONECTADO = "Desconectado"
const val CONECTADO = "Conectado"
//Childs
const val CHILD_BLUETOOTH = "bluetooth"
const val TRANSFERENCIA = "transferencia"
const val ALERTA = "alerta"
//Variables Firebase
const val VELOCIDAD_MOTOR = "velocidad_motor"
const val TEMPERATURA_DESEADA = "temperatura_deseada"
const val TEMPERATURA_ACTUAL = "temperatura_actual"

const val VELOCIDAD_MOTORBT = "velocidad_motor:"
const val TEMPERATURA_DESEADABT = "temperatura_deseada:"
const val TEMPERATURA_ACTUALBT = "temperatura_actual:"

object VariablesAlmacenadasExtrusora {
    var velocidadMotorEstado: Int by mutableIntStateOf(0)
    var temperaturaDeseadaEstado: Int by mutableIntStateOf(0)
    var transferenciaEstado: Int by mutableIntStateOf(0)
    var alertaEstado: Int by mutableIntStateOf(0)
    var bluetoothEstado: Int by mutableIntStateOf(0)
    var isUpdatingEstado: Boolean by mutableStateOf(false)
    var wifiEstado: Int by mutableIntStateOf(0)
    var temperaturaActualEstado: Int by mutableIntStateOf(0)
    var modoConexionEstado by mutableStateOf(true)
    var estadoConexionBluetoothEstado by mutableStateOf(DESCONECTADO)
    var estadoConexionWifiEstado by mutableStateOf(DESCONECTADO)
}
