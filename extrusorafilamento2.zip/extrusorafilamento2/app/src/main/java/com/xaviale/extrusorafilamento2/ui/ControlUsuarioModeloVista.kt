package com.xaviale.extrusorafilamento2.ui

import android.content.Context
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.toObjects
import com.xaviale.extrusorafilamento2.datos.Alerta
import com.xaviale.extrusorafilamento2.datos.UsuariosDatos
import com.xaviale.extrusorafilamento2.datos.VariablesAlmacenadasExtrusora
import com.xaviale.extrusorafilamento2.datos.VariablesAlmacenadasUsuario
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date

class ControlUsuarioModeloVista : ViewModel() {

    private val autenticacion: FirebaseAuth = Firebase.auth
    private val _cargando = MutableLiveData(false)
    private val usuarioDatos = MutableLiveData<UsuariosDatos?>()

    fun inicioSesion(
        correo: String, contrasenia: String, context: Context, home: () -> Unit
    ) = viewModelScope.launch {
        try {
            autenticacion.signInWithEmailAndPassword(correo, contrasenia).addOnSuccessListener {
                    Toast.makeText(context, "Se inicio sesion correctamente", Toast.LENGTH_LONG)
                        .show()
                    home()
                }.addOnFailureListener {
                    Toast.makeText(context, "Correo o contraseña incorrecta", Toast.LENGTH_LONG)
                        .show()
                }
        } catch (e: Exception) {
            Toast.makeText(
                context, "Excepción durante el inicio de sesión: ${e.message}", Toast.LENGTH_LONG
            ).show()
        }
    }

    fun registrarUsuario(
        nombreUsuario: String,
        correo: String,
        contrasenia: String,
        context: Context,
        home: () -> Unit
    ) {
        try {
            if (_cargando.value == false) {
                _cargando.value = true
                autenticacion.createUserWithEmailAndPassword(correo, contrasenia)
                    .addOnSuccessListener {
                        crearUsuario(nombreUsuario, context) {
                            home()
                        }
                        _cargando.value = false
                    }.addOnFailureListener {
                        Toast.makeText(context, "El usuario ya existe", Toast.LENGTH_LONG).show()
                        _cargando.value = false
                    }
            }
        } catch (e: Exception) {
            Toast.makeText(context, "No se pudo registrar usuario ${e.message}", Toast.LENGTH_LONG)
                .show()
        }
    }

    private fun crearUsuario(nombreUsuario: String?, context: Context, onSuccess: () -> Unit) {
        val usuarioId = autenticacion.currentUser?.uid
        val usuario = UsuariosDatos(
            idUsuario = usuarioId?.trim().toString(),
            nombreUsuario = nombreUsuario?.trim().toString(),
            id = null
        ).paraAsignar()
        FirebaseFirestore.getInstance().collection("usuarios").add(usuario).addOnSuccessListener {
                Toast.makeText(context, "Se registro correctamente", Toast.LENGTH_LONG).show()
                onSuccess()
            }.addOnFailureListener {
                Toast.makeText(context, "Ocurrio un error", Toast.LENGTH_LONG).show()
            }
    }

    private fun obtenerDatosUsuario(onResult: (UsuariosDatos?) -> Unit) {
        val usuarioId = autenticacion.currentUser?.uid
        if (usuarioId != null) {
            FirebaseFirestore.getInstance().collection("usuarios")
                .whereEqualTo("usuario_id", usuarioId).get().addOnSuccessListener { documento ->
                    for (i in documento) {
                        VariablesAlmacenadasUsuario.usuarioNombre =
                            i.getString("nombre_usuario").toString()
                    }
                }.addOnFailureListener {
                    onResult(null)
                }
        } else {
            onResult(null)
        }
    }

    fun almacenarRamDatos() {
        obtenerDatosUsuario { datos ->
            usuarioDatos.value = datos
            VariablesAlmacenadasUsuario.usuarioNombre = datos?.nombreUsuario.toString()
        }
    }

    fun actualizarNombreUsuario(
        nuevoNombreUsuario: String, context: Context, onSuccess: () -> Unit
    ) {
        val usuarioId = autenticacion.currentUser?.uid
        if (usuarioId != null) {
            FirebaseFirestore.getInstance().collection("usuarios")
                //.whereEqualTo("usuario_id",usuarioId)
                .document(usuarioId).update("nombre_usuario", nuevoNombreUsuario)
                .addOnSuccessListener {
                    Toast.makeText(
                        context, "Nombre de usuario actualizado correctamente", Toast.LENGTH_LONG
                    ).show()
                    onSuccess()
                }.addOnFailureListener { e ->
                    Toast.makeText(
                        context,
                        "Error al actualizar nombre de usuario: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
        }
    }

     fun guardarAlertaEnBaseDeDatos() {
        val usuarioId = autenticacion.currentUser?.uid

        if (usuarioId != null) {
            val alertaDatos = hashMapOf(
                "usuario_id" to usuarioId,
                "Fecha yo hora" to Date(System.currentTimeMillis())
            )
            FirebaseFirestore.getInstance().collection("alertas").add(alertaDatos).addOnSuccessListener {
                // Alerta guardada correctamente
            }.addOnFailureListener {
                // Manejar error
            }
        }
    }

    fun obtenerAlertasUsuario() {
        val usuarioId = autenticacion.currentUser?.uid
        if (usuarioId != null) {
            FirebaseFirestore.getInstance().collection("alertas")
                .whereEqualTo("usuario_id", usuarioId)
                .get()
                .addOnSuccessListener { documentos ->
                    VariablesAlmacenadasUsuario.alertas = documentos.toObjects()

                }
                .addOnFailureListener {
                    VariablesAlmacenadasUsuario.alertas = emptyList() // Manejar el caso de error
                }
        } else {
            VariablesAlmacenadasUsuario.alertas = emptyList() // Manejar el caso de error
        }
    }

    fun cerrarSesion(home: () -> Unit) {
        autenticacion.signOut()
        home()
    }

    fun validarEmail(correo: String): Boolean {
        val emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"
        return correo.matches(emailPattern.toRegex())
    }

    fun validarContrasenia(contrasenia: String): Boolean {
        return contrasenia.trim().length >= 8
    }

    fun validarNombreUsuario(nombreUsuario: String): Boolean {
        val nombreUsuarioPattern = "[a-zA-Z0-9]+"
        return nombreUsuario.matches(nombreUsuarioPattern.toRegex())
    }
}